import cv2
import numpy as np
from sklearn import preprocessing
def normalize(img):
    img=img/127.0
    img=img-1
    return img

def preprocess(img):
    img = np.array(img, dtype=np.float32)
    height, width, _ = img.shape
    new_height = height * 256 // min(img.shape[:2])
    new_width = width * 256 // min(img.shape[:2])
    img = cv2.resize(img, (new_width, new_height), interpolation=cv2.INTER_CUBIC)
    
    # Crop
    height, width, _ = img.shape
    startx = width//2 - (224//2)
    starty = height//2 - (224//2)
    img = img[starty:starty+224,startx:startx+224]
    assert img.shape[0] == 224 and img.shape[1] == 224, (img.shape, height, width)
    # img = normalize(img)
    
    img[:,:,0] -= 123.68
    img[:,:,1] -= 116.779
    img[:,:,2] -= 103.939 
    
    # Resize
    return img


def eval_input(iter, eval_image_dir, eval_image_list, class_num, eval_batch_size):
    images = []
    labels = []
    line = open(eval_image_list).readlines()
    for index in range(0, eval_batch_size):
        curline = line[iter * eval_batch_size + index]
        [image_name, label_id] = curline.split(' ')
        image = cv2.imread(eval_image_dir + image_name)
        image = preprocess(image)
        images.append(image)
        labels.append(int(label_id))
        lb = preprocessing.LabelBinarizer()
    lb.fit(range(0, class_num))
    labels = lb.transform(labels)
    return {"input": images, "labels": labels}

calib_image_dir = "/media/DATASET/imagenet2012/val/"
calib_image_list = "/media/DATASET/imagenet2012/val/calibration.txt"
calib_batch_size = 37

def calib_input(iter):
    images = []
    line = open(calib_image_list).readlines()
    for index in range(0, calib_batch_size):
        curline = line[iter * calib_batch_size + index]
        [calib_image_name, label_id] = curline.split(' ')
        image = cv2.imread(calib_image_dir + calib_image_name)
        image = preprocess(image)
        images.append(image)
    return {"input": images}
