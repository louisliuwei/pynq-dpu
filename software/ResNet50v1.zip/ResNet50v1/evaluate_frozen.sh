#!/bin/sh
set -e
# Please set your imagenet validation dataset path here,
IMAGE_DIR=/media/DATASET/imagenet2012/val/
IMAGE_LIST=/media/DATASET/imagenet2012/val.txt

EVAL_BATCHES=1000
BATCH_SIZE=50

python3 eval.py \
  --input_frozen_graph ./frozen_resnet50v1.pb \
  --input_node input \
  --output_node resnet_v1_50/predictions/Reshape_1
  --eval_batches $EVAL_BATCHES \
  --batch_size $BATCH_SIZE \
  --eval_image_dir $IMAGE_DIR \
  --eval_image_list $IMAGE_LIST \
  --gpu 0